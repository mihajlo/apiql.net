<?php

/**
 * Dynamic ApiQL PHP library for ApiQL service
 *
 * @author Mihajlo Siljanoski
 */
class ApiQL
{

    /**
     * Initialize class object
     * 
     * @param array $token Token for web service
     * 
     * @return object|null Return instance of the class or null if missing token
     */
    public function __construct($baseUrl, $token = '')
    {
        if (!$token) {
            return null;
        }
        $this->baseApiUrl = $baseUrl;
        $this->token = $token;
        $this->error = [];
    }

    /**
     * Dynamic API method builder
     * 
     * @param string $methodName name of the method
     * @param array $arguments arguments for that method as array
     * 
     * @return object|false Return object from API call as response
     */
    function __call($methodName, $arguments)
    {
        $parts = explode('_', $methodName);
        $endpoint = @$parts[1];

        $context = stream_context_create(array(
            'http' => array('ignore_errors' => true),
        ));

        if (@$parts[0] == 'get') {

            if (!$arguments || @$arguments[0] == '*' || @$arguments[0] == 'all') {
                $url = $this->baseApiUrl . $endpoint . '?token=' . $this->token;
                if (isset($arguments[1])) {
                    $url .= '&' . http_build_query($arguments[1]);
                }
                $jsonResponse = @file_get_contents($url, false, $context);
                $response = json_decode($jsonResponse, false);
                if ($response->status_code == '200') {
                    return $response->$endpoint;
                }
                $this->error = $response;

                return false;
            }

            $url = $this->baseApiUrl . $endpoint . '/' . @$arguments[0] . '?token=' . $this->token;
            if (isset($arguments[1])) {
                $url .= '&' . http_build_query($arguments[1]);
            }
            $jsonResponse = @file_get_contents($url, false, $context);
            $response = json_decode($jsonResponse, false);
            if ($response->status_code == '200') {
                return $response->$endpoint->data;
            }
            $this->error = $response;

            return false;
        }



        if (@$parts[0] == 'add') {

            $context = stream_context_create([
                'http' => [
                    'method' => 'POST',
                    'header' => 'Content-Type: application/x-www-form-urlencoded',
                    'content' => http_build_query(@$arguments[0]),
                    'ignore_errors' => true
                ],
            ]);
            $url = $this->baseApiUrl . $endpoint . '?token=' . $this->token;
            $jsonResponse = @file_get_contents($url, false, $context);
            $response = json_decode($jsonResponse);
            if ($response->status_code == '200') {
                return $response->$endpoint->data;
            }
            $this->error = $response;

            return false;
        }


        if (@$parts[0] == 'edit') {

            $context = stream_context_create([
                'http' => [
                    'method' => 'POST',
                    'header' => 'Content-Type: application/x-www-form-urlencoded',
                    'content' => http_build_query(@$arguments[1]),
                    'ignore_errors' => true
                ],
            ]);
            $url = $this->baseApiUrl . $endpoint . '/' . @$arguments[0] . '?token=' . $this->token;
            $jsonResponse = @file_get_contents($url, false, $context);
            $response = json_decode($jsonResponse);
            if ($response->status_code == '200') {
                return $response->$endpoint->data;
            }
            $this->error = $response;

            return false;
        }

        if (@$parts[0] == 'delete') {

            $context = stream_context_create([
                'http' => [
                    'method' => 'DELETE',
                    'ignore_errors' => true
                ],
            ]);
            $url = $this->baseApiUrl . $endpoint . '/' . @$arguments[0] . '?token=' . $this->token;
            $jsonResponse = @file_get_contents($url, false, $context);
            $response = json_decode($jsonResponse);
            if ($response->status_code == '200') {
                return true;
            }
            $this->error = $response;

            return false;
        }
        return false;
    }

    /**
     * Get errors from service
     * 
     * @return object Return service errors
     */
    public function error()
    {
        return $this->error;
    }
}
